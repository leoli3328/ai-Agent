
import random

class CustomerAgent:
    def analyze(self, info):
        if "物流" in info:
            return "高潜力客户，建议优先拜访"
        elif "餐饮" in info:
            return "中等需求，可跟进"
        else:
            return "需求不明确，建议探索沟通"


class SalesAgent:
    def reply(self, message):
        responses = [
            "我们现在有合作方了",
            "你们价格多少？",
            "可以了解一下",
            "暂时不需要"
        ]
        return random.choice(responses)


class ReviewAgent:
    def review(self, dialogue):
        if "谢谢" in dialogue:
            return "你过早结束对话，建议增加引导"
        elif "价格" in dialogue:
            return "客户关注价格，应强调价值"
        else:
            return "建议多问开放问题"
