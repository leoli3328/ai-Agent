
# 多Agent销售系统（高级版）

## 模块
- CustomerAgent：客户分析
- SalesAgent：对话模拟
- ReviewAgent：复盘优化

## 运行
python main.py

## 升级方向
- 接入OpenAI API
- 增加CRM数据库
- Web界面
