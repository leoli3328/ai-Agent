
from agents import CustomerAgent, SalesAgent, ReviewAgent

def main():
    customer_agent = CustomerAgent()
    sales_agent = SalesAgent()
    review_agent = ReviewAgent()

    print("=== 多Agent销售系统 ===")

    while True:
        print("\n1. 客户分析")
        print("2. 销售对话模拟")
        print("3. 对话复盘")
        print("4. 退出")

        choice = input("选择：")

        if choice == "1":
            info = input("输入行业或客户信息：")
            print(customer_agent.analyze(info))

        elif choice == "2":
            msg = input("你说：")
            print("客户：", sales_agent.reply(msg))

        elif choice == "3":
            dialogue = input("输入对话：")
            print(review_agent.review(dialogue))

        elif choice == "4":
            break

if __name__ == "__main__":
    main()
